import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Chat, Modality, Blob as GenAI_Blob, Part, LiveServerMessage } from '@google/genai';
import { Message, Role } from './types';
import { Header } from './components/Header';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';


// Helper to convert a File object to a Gemini Part
async function fileToGeminiPart(file: File): Promise<Part> {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
}

// Helper to encode raw audio bytes to base64
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Helper to create a GenAI Blob for the Live API
function createBlob(data: Float32Array): GenAI_Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const App: React.FC = () => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    { role: Role.MODEL, content: "Hello! I am Babaji, your personal AI assistant. How can I help you today?" }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [selectedImageDataUrl, setSelectedImageDataUrl] = useState<string | null>(null);

  const [isRecording, setIsRecording] = useState(false);
  const [isTtsEnabled, setIsTtsEnabled] = useState(false);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const aiRef = useRef<GoogleGenAI | null>(null);

  const initializeChat = useCallback(() => {
    try {
      if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set.");
      }
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      aiRef.current = ai;
      
      const chatSession = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: "You are Babaji, a friendly, helpful, and slightly witty personal AI assistant. Your responses should be clear, concise, and helpful. You are designed to work seamlessly on both Windows and Android, so your tone is modern and adaptable. Use markdown for formatting when appropriate. If you are analyzing an image, describe it clearly before answering any user questions.",
        },
      });
      setChat(chatSession);
    } catch (e) {
      console.error("Failed to initialize Gemini:", e);
      setError("Failed to initialize the AI. Please ensure your API key is configured correctly.");
    }
  }, []);
  
  const speak = useCallback((text: string) => {
    if (!text || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel(); // Stop any previous speech
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
  }, []);

  const handleToggleTts = useCallback(() => {
    setIsTtsEnabled(prev => {
        const newState = !prev;
        if (!newState) {
            window.speechSynthesis.cancel(); // Stop speech if TTS is disabled
        }
        return newState;
    });
  }, []);

  useEffect(() => {
    initializeChat();
  }, [initializeChat]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = useCallback(async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (isLoading || (!userInput.trim() && !selectedImage)) return;

    const userMessage: Message = { 
        role: Role.USER, 
        content: userInput.trim(),
        image: selectedImageDataUrl ?? undefined,
    };
    setMessages(prev => [...prev, userMessage, { role: Role.MODEL, content: '' }]);

    const textInput = userInput.trim();
    const imageInput = selectedImage;

    setUserInput('');
    setSelectedImage(null);
    setSelectedImageDataUrl(null);
    setIsLoading(true);
    setError(null);
    
    let fullResponse = '';

    try {
      if (!chat) throw new Error("Chat not initialized");

      const parts: (string | Part)[] = [textInput];
      if (imageInput) {
        const imagePart = await fileToGeminiPart(imageInput);
        parts.push(imagePart);
      }
      
      const stream = await chat.sendMessageStream({ message: parts });

      for await (const chunk of stream) {
        const chunkText = chunk.text;
        fullResponse += chunkText;
        setMessages(prev => {
            const newMessages = [...prev];
            const lastIndex = newMessages.length - 1;
            newMessages[lastIndex] = {
                ...newMessages[lastIndex],
                content: newMessages[lastIndex].content + chunkText,
            };
            return newMessages;
        });
      }
      if (isTtsEnabled) {
          speak(fullResponse);
      }
    } catch (e: any) {
      console.error("Error sending message:", e);
      let errorMessage = "An unexpected error occurred. Please try again.";

      if (!navigator.onLine) {
        errorMessage = "Network connection lost. Please check your internet connection and try again.";
      } else if (e instanceof Error && e.message) {
        const message = e.message.toLowerCase();
        if (message.includes('api key not valid')) {
          errorMessage = "Authentication Error: The API key is not valid. Please check your configuration.";
        } else if (message.includes('quota')) {
          errorMessage = "API Limit Reached: The request quota has been exceeded. Please try again later.";
        } else if (message.includes('429')) { // Fallback for rate limiting
          errorMessage = "Too many requests. Please wait a moment and try again.";
        } else if (message.includes('network') || message.includes('fetch')) {
          errorMessage = "Network Error: Could not connect to the AI service. Please verify your connection.";
        }
      }
      
      setMessages(prev => {
          const newMessages = [...prev];
          const lastIndex = newMessages.length - 1;
          if(newMessages[lastIndex]?.role === Role.MODEL && newMessages[lastIndex]?.content === '') {
             newMessages[lastIndex] = { ...newMessages[lastIndex], content: errorMessage, role: Role.MODEL };
          } else {
            newMessages.push({role: Role.MODEL, content: errorMessage});
          }
          return newMessages;
        });
      setError(errorMessage);
      if (isTtsEnabled) {
          speak(errorMessage);
      }
    } finally {
      setIsLoading(false);
    }
  }, [userInput, isLoading, chat, selectedImage, selectedImageDataUrl, isTtsEnabled, speak]);

  const handleClearChat = useCallback(() => {
    if (window.confirm("Are you sure you want to clear the chat history? This action cannot be undone.")) {
      window.speechSynthesis.cancel();
      initializeChat();
      setMessages([
        { role: Role.MODEL, content: "Hello! I am Babaji, your personal AI assistant. How can I help you today?" }
      ]);
      setError(null);
      setIsLoading(false);
      setSelectedImage(null);
      setSelectedImageDataUrl(null);
    }
  }, [initializeChat]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImageDataUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setSelectedImage(null);
    setSelectedImageDataUrl(null);
  };
  
  const stopRecording = useCallback(() => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => session.close());
      sessionPromiseRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    if (mediaStreamSourceRef.current) {
      mediaStreamSourceRef.current.disconnect();
      mediaStreamSourceRef.current = null;
    }
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current.onaudioprocess = null;
      scriptProcessorRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
    }
    setIsRecording(false);
  }, []);

  const startRecording = useCallback(async () => {
    setIsRecording(true);
    setUserInput(''); // Clear input for transcription
    let currentInputTranscription = '';
    
    try {
        if (!aiRef.current) throw new Error("AI not initialized");
        
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;

        sessionPromiseRef.current = aiRef.current.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => {
                    const source = audioContextRef.current!.createMediaStreamSource(stream);
                    mediaStreamSourceRef.current = source;
                    const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = scriptProcessor;

                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob = createBlob(inputData);
                        sessionPromiseRef.current?.then((session) => {
                            session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(audioContextRef.current!.destination);
                },
                onmessage: (message: LiveServerMessage) => {
                    if (message.serverContent?.inputTranscription) {
                        const text = message.serverContent.inputTranscription.text;
                        currentInputTranscription += text;
                        setUserInput(currentInputTranscription);
                    }
                    if (message.serverContent?.turnComplete) {
                        const fullInput = currentInputTranscription;
                        currentInputTranscription = '';
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Live session error:', e);
                    setError("An error occurred during transcription.");
                    stopRecording();
                },
                onclose: () => {
                    // console.log('Live session closed');
                },
            },
            config: {
                inputAudioTranscription: {},
                responseModalities: [Modality.AUDIO],
            },
        });

    } catch (err) {
        console.error('Failed to start recording:', err);
        setError("Could not access microphone. Please grant permission and try again.");
        stopRecording();
    }
  }, [stopRecording]);

  const toggleRecording = useCallback(() => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  }, [isRecording, startRecording, stopRecording]);

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 text-white font-sans">
      <Header 
        onClearChat={handleClearChat}
        isTtsEnabled={isTtsEnabled}
        onToggleTts={handleToggleTts}
      />
      <main className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto">
          {messages.map((msg, index) => (
            <ChatMessage 
              key={index} 
              message={msg}
              isError={!!error && index === messages.length -1 && msg.content === error}
            />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </main>
      <ChatInput
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
        onSubmit={handleSendMessage}
        isLoading={isLoading}
        onImageChange={handleImageChange}
        onRemoveImage={handleRemoveImage}
        selectedImage={selectedImageDataUrl}
        onMicrophoneClick={toggleRecording}
        isRecording={isRecording}
      />
    </div>
  );
};

export default App;