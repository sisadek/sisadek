
import React from 'react';

export const Avatar: React.FC = () => {
  return (
    <div className="relative flex-shrink-0 w-10 h-10">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full blur-md opacity-75"></div>
      <div className="relative flex items-center justify-center w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-700 rounded-full text-white font-bold text-xl shadow-lg ring-2 ring-white/10">
        B
      </div>
    </div>
  );
};
