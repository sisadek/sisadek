import React, { useState } from 'react';
import { Message, Role } from '../types';
import { Avatar } from './Avatar';
import { LoadingIndicator } from './LoadingIndicator';

interface ChatMessageProps {
  message: Message;
  isError?: boolean;
}

const CopyIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
);

const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
);

const ExclamationIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
);

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isError }) => {
  const isModel = message.role === Role.MODEL;
  const [isCopied, setIsCopied] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);

  const handleCopy = () => {
    if (!message.content) return;
    navigator.clipboard.writeText(message.content);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };
  
  const modelBubbleClasses = isError
    ? 'bg-red-900/50 border border-red-500/50 text-red-200 rounded-bl-none'
    : 'bg-gray-800 text-gray-200 rounded-bl-none';

  return (
    <>
      <div className={`flex items-start gap-4 my-6 ${isModel ? 'justify-start' : 'justify-end'}`}>
        {isModel && <Avatar />}
        <div className={`relative group max-w-lg md:max-w-xl lg:max-w-2xl px-5 py-3 rounded-2xl shadow-md ${isModel ? modelBubbleClasses : 'bg-blue-600 text-white rounded-br-none'}`}>
          {message.image && (
            <img 
              src={message.image} 
              alt="User upload" 
              className="rounded-lg mb-2 max-w-xs max-h-64 object-contain cursor-pointer transition-transform hover:scale-105 duration-200"
              onClick={() => setIsLightboxOpen(true)}
            />
          )}
          <div className="prose prose-invert prose-p:my-2 prose-headings:my-3 max-w-none">
            {isError && isModel && (
                <div className="flex items-center gap-2 not-prose mb-2">
                    <ExclamationIcon className="w-5 h-5 text-red-400 flex-shrink-0" />
                    <span className="font-semibold text-red-300">Request Failed</span>
                </div>
            )}
            {message.content.length > 0 ? (
              message.content.split('\n').map((line, index) => (
                <p key={index} className="my-0">{line}</p>
              ))
            ) : (
              isModel && <LoadingIndicator />
            )}
          </div>
          {message.content && (
            <button 
              onClick={handleCopy} 
              aria-label="Copy message"
              className={`absolute top-2 right-2 p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 ${
                isModel 
                  ? 'bg-gray-700/50 text-gray-400 hover:text-white hover:bg-gray-600'
                  : 'bg-blue-500/50 text-blue-100 hover:text-white hover:bg-blue-400'
              }`}
            >
              {isCopied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>

      {isLightboxOpen && message.image && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          style={{ animation: 'fade-in 0.2s ease-out forwards' }}
          onClick={() => setIsLightboxOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Image lightbox"
        >
           <style>{`
            @keyframes fade-in {
              from { opacity: 0; }
              to { opacity: 1; }
            }
          `}</style>
          <img 
            src={message.image} 
            alt="User upload lightbox" 
            className="max-w-[90vw] max-h-[90vh] object-contain rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
          <button 
            className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
            onClick={() => setIsLightboxOpen(false)}
            aria-label="Close lightbox"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}
    </>
  );
};