import React from 'react';

interface ChatInputProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
  isLoading: boolean;
  onImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveImage: () => void;
  selectedImage: string | null;
  onMicrophoneClick: () => void;
  isRecording: boolean;
}

const SendIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
    </svg>
);

const PaperclipIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m18.375 12.739-7.693 7.693a4.5 4.5 0 0 1-6.364-6.364l10.94-10.94A3 3 0 1 1 19.5 7.372L8.552 18.32m.009-.01-.01.01m5.699-9.941-7.81 7.81a1.5 1.5 0 0 0 2.122 2.122l7.81-7.81" />
    </svg>
);

const MicrophoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 0 0 6-6v-1.5m-6 7.5a6 6 0 0 1-6-6v-1.5m12 0v-1.5a6 6 0 0 0-12 0v1.5m0 0a9 9 0 0 0 18 0" />
    </svg>
);

const XCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z" clipRule="evenodd" />
    </svg>
);

export const ChatInput: React.FC<ChatInputProps> = ({ value, onChange, onSubmit, isLoading, onImageChange, selectedImage, onRemoveImage, onMicrophoneClick, isRecording }) => {
    const textareaRef = React.useRef<HTMLTextAreaElement>(null);
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            const form = e.currentTarget.closest('form');
            if (form && !isLoading && (value.trim() || selectedImage)) {
                form.requestSubmit();
            }
        }
    };
    
    React.useEffect(() => {
        const textarea = textareaRef.current;
        if (textarea) {
            textarea.style.height = 'auto';
            const scrollHeight = textarea.scrollHeight;
            textarea.style.height = `${scrollHeight}px`;
        }
    }, [value]);


  return (
    <footer className="bg-gray-900/50 backdrop-blur-sm p-4 border-t border-white/10 sticky bottom-0 z-10">
      <div className="max-w-4xl mx-auto">
        {selectedImage && (
             <div className="p-2 mb-2 bg-gray-800/50 border border-gray-700 rounded-lg">
                <div className="relative group w-fit">
                    <img src={selectedImage} alt="Image preview" className="max-h-36 rounded-md object-contain" />
                    <button 
                        onClick={onRemoveImage} 
                        className="absolute top-1 right-1 p-0.5 bg-black/60 text-white rounded-full opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity"
                        aria-label="Remove image"
                    >
                        <XCircleIcon className="w-6 h-6" />
                    </button>
                </div>
            </div>
        )}
        <form onSubmit={onSubmit} className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg blur opacity-0 group-focus-within:opacity-75 transition duration-200"></div>
          <textarea
            ref={textareaRef}
            value={value}
            onChange={onChange}
            onKeyDown={handleKeyDown}
            placeholder={isRecording ? "Listening..." : "Ask Babaji anything..."}
            rows={1}
            disabled={isLoading || isRecording}
            className="relative w-full bg-gray-800 text-white rounded-lg p-4 pr-32 resize-none focus:outline-none transition-shadow disabled:opacity-50 max-h-48"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center space-x-2">
            <input
                type="file"
                ref={fileInputRef}
                onChange={onImageChange}
                accept="image/*"
                className="hidden"
            />
            <button type="button" onClick={() => fileInputRef.current?.click()} disabled={isLoading || isRecording} className="p-2 text-gray-400 hover:text-white disabled:text-gray-600 transition-colors">
                <PaperclipIcon className="w-6 h-6"/>
            </button>
             <button type="button" onClick={onMicrophoneClick} disabled={isLoading} className={`p-2 transition-colors ${isRecording ? 'text-red-500 animate-pulse' : 'text-gray-400 hover:text-white'}`}>
                <MicrophoneIcon className="w-6 h-6"/>
            </button>
            <button type="submit" disabled={isLoading || (!value.trim() && !selectedImage)} className="p-2 rounded-full bg-blue-600 text-white hover:bg-blue-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors">
                <SendIcon className="w-6 h-6"/>
            </button>
          </div>
        </form>
      </div>
    </footer>
  );
};